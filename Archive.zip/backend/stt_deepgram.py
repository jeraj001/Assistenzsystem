import io
import os
import wave

import httpx
import numpy as np
import sounddevice as sd


def record_wav_bytes(duration_sec: float = 6.0, sample_rate: int = 48000) -> bytes:
    """Records clean 48 kHz mono 16-bit PCM audio from the default mic."""
    frames = int(duration_sec * sample_rate)
    audio = sd.rec(frames, samplerate=sample_rate, channels=1, dtype="int16")
    sd.wait()

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # 16-bit = 2 bytes
        wf.setframerate(sample_rate)
        wf.writeframes(np.asarray(audio, dtype=np.int16).tobytes())
    return buf.getvalue()


async def transcribe_with_deepgram(wav_bytes: bytes) -> tuple[str, int]:
    """Sends WAV bytes to Deepgram Nova-3 and returns (transcript, confidence_pct)."""
    api_key = os.getenv("DEEPGRAM_API_KEY", "").strip()
    if not api_key or api_key == "YOUR_KEY_HERE":
        raise RuntimeError("DEEPGRAM_API_KEY is missing in .env")

    language = os.getenv("DEEPGRAM_LANGUAGE", "de").strip()
    url = "https://api.deepgram.com/v1/listen"
    params: list[tuple[str, str]] = [
        ("model", "nova-3"),
        ("smart_format", "true"),
        ("punctuate", "true"),
        ("language", language),
    ]

    # Bias multilingual mode toward German and English so it stays precise
    if language == "multi":
        params.append(("language_hint", "de"))
        params.append(("language_hint", "en"))

    headers = {
        "Authorization": f"Token {api_key}",
        "Content-Type": "audio/wav",
    }

    async with httpx.AsyncClient(timeout=25.0) as client:
        resp = await client.post(url, params=params, headers=headers, content=wav_bytes)
        resp.raise_for_status()
        data = resp.json()

    alt = data["results"]["channels"][0]["alternatives"][0]
    transcript = alt.get("transcript", "").strip()
    confidence_pct = round(float(alt.get("confidence", 0.0)) * 100)
    return transcript, confidence_pct
